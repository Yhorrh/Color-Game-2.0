import random
import tkinter as tk
from tkinter import messagebox
import pygame

class ColorGame:
    def __init__(self, master):
        self.master = master
        self.master.title("Color Memory Game")
        self.master.configure(bg='sky blue')
        self.colors = ["blue", "green", "pink", "red", "orange", "yellow", "purple", "indigo", "teal","olive","maroon","navy","lime","magenta","cyan","brown"]
        self.sequence = []  
        self.player_input = []  
        self.buttons = []
        self.success_count = 0  

        pygame.mixer.init()
        self.background_music = "windowchill.mp3"  # Replace with your music file
        pygame.mixer.music.load(self.background_music)
        pygame.mixer.music.play(-1)  # Loop the mu

    
        self.counter_frame = tk.Frame(self.master, bg='sky blue')
        self.counter_frame.grid(row=0, column=0, padx=10, pady=10, sticky="n")

       
        self.counter_label = tk.Label(self.counter_frame, text=f"Success Count: {self.success_count}", font=("Arial", 12), bg='sky blue')
        self.counter_label.pack()


        self.retry_button = tk.Button(self.counter_frame, text="Retry", command=self.reset_game, font=("Arial", 12))
        self.retry_button.pack(pady=(10, 0))

        self.info_button = tk.Button(self.counter_frame, text="Info", command=self.show_info, font=("Arial", 12))
        self.info_button.pack(pady=(10, 0))
 

        self.quit_button = tk.Button(self.counter_frame, text="Quit", command=self.quit_game, font=("Arial", 12))
        self.quit_button.pack(pady=(10, 0))  

        
        self.grid_frame = tk.Frame(self.master, bg='sky blue')
        self.grid_frame.grid(row=0, column=1, padx=10, pady=10)

        self.create_board()
        self.sequence_length = 1
        self.show_info()
        self.next_turn()

    def create_board(self):
        for i in range(4):
            for j in range(4):
                color = self.colors[i * 4 + j]  
                button = tk.Button(self.grid_frame, bg=color, width=8, height=3,
                                   highlightbackground="black", highlightthickness=2,
                                   command=lambda color=color: self.player_turn(color))
                button.grid(row=i, column=j, padx=2, pady=2)  
                button.config(state=tk.DISABLED)  
                self.buttons.append(button)

    def start_game(self):
        self.master.after(5000, self.next_turn)

    def next_turn(self):
        self.player_input = []  
        next_color = random.choice(self.colors)
        self.sequence.append(next_color)  
        self.highlight_sequence()  

    def highlight_sequence(self):
        for button in self.buttons:
            button.config(state=tk.DISABLED)

        for index, color in enumerate(self.sequence):
            self.master.after(index * 1000, self.flash_button, color, index) 
        
        total_flash_time = len(self.sequence) * 1000  # Total duration of flashing sequence
        self.master.after(total_flash_time, self.enable_buttons)

    def flash_button(self, color, index):
        button_index = self.colors.index(color)
        button = self.buttons[button_index]
        
        original_color = button['bg']
        button.config(bg='white')  
        self.master.after(500, lambda: button.config(bg=original_color))  

        if index == len(self.sequence) - 1:
            self.master.after(1000, self.enable_buttons)  

    def enable_buttons(self):
        for button in self.buttons:
            button.config(state=tk.NORMAL)  

    def player_turn(self, color):
        self.player_input.append(color) 

        if self.player_input == self.sequence:
            self.success_count += 1  
            self.counter_label.config(text=f"Success Count: {self.success_count}")  
            
            if len(self.sequence) < 30:  
                messagebox.showinfo("Good job!", "Correct sequence!")
                self.next_turn()  
            else:
                messagebox.showinfo("Congratulations!", "You've completed the game!")
                self.reset_game()  
        elif self.player_input[-1] != self.sequence[len(self.player_input) - 1]:
            messagebox.showerror("Oops!", "Wrong sequence! Try again.")
            self.reset_game()  

    def reset_game(self):
        # Disable the Retry button and schedule re-enabling it after 2 seconds
        self.retry_button.config(state=tk.DISABLED)
        self.master.after(2000, lambda: self.retry_button.config(state=tk.NORMAL))

        self.sequence = [] 
        self.player_input = []  
        self.success_count = 0  
        self.counter_label.config(text="Success Count: 0")  

        # Disable all game buttons initially
        for button in self.buttons:
            button.config(state=tk.DISABLED)  
        self.master.after(1000, self.next_turn) 

    def quit_game(self):
        self.master.quit()  

    def show_info(self):
        messagebox.showinfo(
            "How to Play",
            "1. Watch the color sequence as it flashes on the grid.\n"
            "2. After the sequence stops flashing, click the colors in the same order.\n"
            "3. Each round adds one more color to the sequence.\n"
            "4. Continue until you complete all 30 rounds or make a mistake.\n"
            "5. Use the 'Retry' button to restart the game at any time.\n"
            "\n"
            "Music: WindowChill by Keestak"
        )

def main():
    root = tk.Tk()
    ColorGame(root)
    root.mainloop()

if __name__ == "__main__":
    main()














